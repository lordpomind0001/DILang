import main
main.run("test.dil")